#pragma once

#include "serialport.h"
#include <boost/function.hpp>
#include <boost/bind/placeholders.hpp>

#pragma pack(push, 1)
struct IMuInputData
{
    IMuInputData()
    {
        memset(this, 0, sizeof(IMuInputData));
        unsigned char szT[4] = {0x00, 0x00, 0x00, 0x26};
        memcpy(szHeader, szT, 4);
    }
    unsigned char szHeader[4];  //0x00 0x00 0x00 0x26
    short nSpeedML;             //round per min
    short nSpeedMR;
    short nSpeedSL;
    short nSpeedSR;
    unsigned char szNull0[35];
    unsigned char cBackSign;
    unsigned char szNull1[47];
    unsigned char nSum;
};
#pragma pack(pop)

class CCmdTransferParam
{
public:
    std::string port_in;
    std::string port_out;
    CCmdTransferParam()
    {
        port_in = "/dev/ttyS0";
        port_out = "/dev/ttyS1";
    }
};

class CCmdTransfer
{
public:
    CCmdTransfer();
    ~CCmdTransfer();
    int Init(CCmdTransferParam& param);
    void dataCallBackProcess(const char* pBuf, int nBufLen);
    void sendRequireProcess();
//    void sendDataExternalProcess();
    bool Start();
    int Stop();
private:
    IMuInputData DataTrans(float l, float r);
    int ParseData();
    int ParseDataEx();
    int ParseDataLine(char* pBuf, int nLen);
//    bool m_bIsRun;
    SerialPort m_port_in;
    SerialPort m_port_out;
    CCmdTransferParam m_param;
    float m_dDmiLeft;
    float m_dDmiRight;
//    boost::mutex m_lock;
    std::vector<char> m_buf;
//    boost::thread* m_pThreadCmd;
//    boost::thread* m_pThreadExternal;
    boost::asio::io_service m_io;
    int m_nSendReqCont;
};
