#include "CmdTransfer.h"

int main(int argc, char* argv[])
{
    CCmdTransfer aaa;
    IMuInputData ttt;
    int i = sizeof(ttt);

    return 0;
}
