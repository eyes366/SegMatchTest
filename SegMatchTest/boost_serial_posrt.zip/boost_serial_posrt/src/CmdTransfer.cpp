#include "CmdTransfer.h"


using namespace std;

CCmdTransfer::CCmdTransfer()
{
//    m_bIsRun = false;
    m_dDmiLeft = 0.f;
    m_dDmiRight = 0.f;
//    m_pThreadCmd = 0;
    m_nSendReqCont = 0;
//    m_pThreadExternal = 0;
}
CCmdTransfer::~CCmdTransfer()
{

}
int CCmdTransfer::Init(CCmdTransferParam& param)
{
    m_param = param;
}
int CCmdTransfer::ParseDataLine(char* pBuf, int nLen)
{
    int nStart0 = -1;
    int nEnd0 = -1;
    int nStart1 = -1;
    int nEnd1 = -1;
    for (unsigned int i = 0; i < nLen; i++)
    {
        if(pBuf[i] == '=')
        {
            nStart0 = i+1;
        }
        if(pBuf[i] == ':')
        {
            nEnd0 = i-1;
            nStart1 = i+1;
        }
        if(pBuf[i] == '\r')
        {
            nEnd1 = i-1;
        }
    }

    if (0 <= nStart0 && nStart0 < nEnd0 &&
            nEnd0 < nStart1 && nStart1 < nEnd1 &&
            nEnd1 < nLen-1)
    {
        float l,r;
        char szTemp[10];
        memset(szTemp, 0, 10);
        memcpy(szTemp, pBuf+nStart0, nEnd0-nStart0+1);
        l = atof(szTemp);
        memset(szTemp, 0, 10);
        memcpy(szTemp, pBuf+nStart1, nEnd1-nStart1+1);
        r = atof(szTemp);
//        m_lock.lock();
        m_dDmiLeft = l;
        m_dDmiRight = r;
        IMuData IMuData;
        IMuData.nSpeedML = m_dDmiLeft;
        IMuData.nSpeedSL = m_dDmiLeft;
        IMuData.nSpeedMR = m_dDmiRight;
        IMuData.nSpeedSR = m_dDmiRight;
        if (IMuData.nSpeedML > 0 && IMuData.nSpeedMR > 0)
        {
            IMuData.cBackSign = 0x0b;
        }
        else
        {
            IMuData.cBackSign = 0x00;
        }
        unsigned char nSum = 0;
        unsigned char* pData = (unsigned char*)(&IMuData);
        for (unsigned int i = 0;i < 95; i++)
        {
            nSum += pData[i];
        }
//        m_lock.unlock();
    }

}
int CCmdTransfer::ParseDataEx()
{
    char szHeader[2] = {'S', '='};
    int nHeaderLen = 2;
    for (unsigned int i = 0; i < m_buf)
}
int CCmdTransfer::ParseData()
{
    char szHeader[2] = {'S', '='};
    int nHeaderLen = 2;
    int nFindHeaderInd = 0;
    int nHeaderStart = -1;
    int nHeaderEnd = -1;
    int nDataEnd = -1;
    int nParseState = 0;    //0:find header start  1:find header end  2:find data end 3:check  4:parse
    for (unsigned int i = 0; i < m_buf.size(); i++)
    {
        if (nParseState == 0)//
        {
            if (m_buf[i] == szHeader[nFindHeaderInd])
            {
                nFindHeaderInd++;
                nHeaderStart = i;
                nParseState = 1;
            }
            else
            {
                nFindHeaderInd = 0;
                nHeaderStart = -1;
            }
        }
        else if (nParseState == 1)
        {
            if (nFindHeaderInd >= nHeaderLen)
            {
                nParseState = 2;
                nHeaderEnd = i;
            }
            if (m_buf[i] == szHeader[nFindHeaderInd])
            {
                nFindHeaderInd++;
            }
            else
            {
                nFindHeaderInd = 0;
                nHeaderStart = -1;
                nParseState = 0;
            }
        }
        else if (nParseState == 2)
        {
            if (m_buf[i] == '\r')
            {
                nDataEnd = i;
                nFindHeaderInd = 0;
                nParseState = 0;
                ParseDataLine(m_buf.data()+nHeaderStart, nDataEnd-nHeaderStart+1);
            }
        }
    }

    if (nParseState == 0)
    {
        m_buf.clear();
    }
    else
    {
        m_buf.erase(m_buf.begin(), m_buf.begin()+nHeaderStart);
    }

    return 1;
}
void CCmdTransfer::dataCallBackProcess(const char* pBuf, int nBufLen)
{
    for (int i = 0; i < nBufLen; i++)
    {
        m_buf.push_back(pBuf[i]);
    }
    ParseData();
}
//void CCmdTransfer::sendDataExternalProcess()
//{
//    IMuInputData DataOut;
//    while(m_bIsRun && m_port_out.isOpened())
//    {
//        boost::this_thread::sleep(boost::posix_time::milliseconds(8));
//        m_lock.lock();
//        DataOut.
//        m_lock.unlock();
//    }
//}

void CCmdTransfer::sendRequireProcess()
{
    m_nSendReqCont++;
    char szCmd[] = {'!', 'A', '\r'};
    if (m_bIsRun && m_port_in.isOpened())
    {
        m_port_in.write(szCmd, 3);
    }
    if (m_nSendReqCont%125 == 0)
    {
        cout << "Requre send cont: " << m_nSendReqCont << endl;
    }
//    unsigned int nCont = 0;
//    while(m_bIsRun && m_port_in.isOpened())
//    {
//        m_port_in.write(szCmd, 3);
//        boost::this_thread::sleep(boost::posix_time::milliseconds(8));
//        nCont++;

//    }
}
IMuInputData CCmdTransfer::DataTrans(float l, float r)
{

}
int CCmdTransfer::Stop()
{
//    m_bIsRun = false;
    m_io.stop();
    m_io.reset();
    m_port_in.close();
    m_port_out.close();
//    m_pThreadCmd->join();
//    m_pThreadExternal->join();

    return 1;
}
bool CCmdTransfer::Start()
{
    RecieveCallBack func;
    func = boost::bind(&CCmdTransfer::dataCallBackProcess, this, _1, _2);
    m_port_in.setCallBack(func);

    if (!m_port_in.init_port(m_param.port_in.c_str()), 115200)
    {
        std::cout << "m_port_in open failed:" << m_param.port_in << endl;
        return false;
    }

    if (!m_port_out.init_port(m_param.port_out.c_str()), 115200)
    {
        std::cout << "port_out open failed:" << m_param.port_out << endl;
        m_port_in.close();
        return false;
    }

//    m_bIsRun = true;
//    boost::function<void()> func_send;
//    func_send = boost::bind(&CCmdTransfer::print, this, boost::asio::placeholders::error);
//    m_pThreadCmd = new boost::thread(func_send);
    boost::asio::deadline_timer timer(m_io, boost::posix_time::milliseconds(8));
    timer.async_wait(boost::bind(&CCmdTransfer::sendRequireProcess, this));
    m_io.run();

//    boost::function<void()> func_send_;
//    func_send_ = boost::bind(&CCmdTransfer::sendDataExternalProcess, this);
//    m_pThreadExternal = new boost::thread(func_send_);

    return true;
}
